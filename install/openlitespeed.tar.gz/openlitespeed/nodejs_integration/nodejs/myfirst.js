// console.log('myfirst.node Hello LiteSpeed Node JS')

response.write("<html>\r\n"
                + "<body>\r\n"
                + "Hello LiteSpeed from myfirst.node\r\n"
                + "</body>\r\n"
                + "</html>\r\n");
// console.log('myfirst.node Bye LiteSpeed Node JS')

