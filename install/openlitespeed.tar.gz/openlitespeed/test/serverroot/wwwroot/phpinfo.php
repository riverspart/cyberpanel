<?php 
     setcookie('try_login', 1, time()+30);
?>
<HTML>
<BODY>
   <?php phpinfo() ?>
</BODY>
</HTML>
